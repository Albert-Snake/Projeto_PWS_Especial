<?php
use ActiveRecord\Model;

class administrator extends Model{


}
