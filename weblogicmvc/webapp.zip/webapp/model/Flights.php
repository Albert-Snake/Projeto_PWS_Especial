<?php
use ActiveRecord\Model;

class flights extends Model{


}
