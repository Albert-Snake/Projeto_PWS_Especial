<?php
use ActiveRecord\Model;

class airport extends Model{


}
