<?php
use ActiveRecord\Model;

class airplanes extends Model{


}
