<?php

use \ActiveRecord\Model;

class Test extends Model
{

}