<?php
use ActiveRecord\Model;

class user extends Model{


}
