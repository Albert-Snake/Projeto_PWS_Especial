<?php
use ArmoredCore\WebKernel\ArmoredCore;

/**
 * Created by PhpStorm.
 * User: smendes
 * Date: 06-04-2017
 * Time: 18:13
 */
class MetaArmCoreModel
{

    public static function getComponents(){
        return ArmoredCore::getComponents();
    }


}