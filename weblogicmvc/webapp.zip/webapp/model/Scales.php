<?php
use ActiveRecord\Model;

class scales extends Model{


}
