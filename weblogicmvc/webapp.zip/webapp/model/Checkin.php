<?php
use ActiveRecord\Model;

class checkin extends Model{


}
